---
title: "Unit Test"
weight: 12
pre: "<b>1-2 </b>"
tag:
  - UnitTest
  - JAVA
  - Junit
---

## What is Unit Test?

UnitTest is a **Module** that tests another **Module**. software is composed of several modules, and UnitTest means `minimum level test unit` that can test whether each of these modules functions normally. This workshop will perform **UnitTest** using **Junit**  in **JAVA**.

![AWSDataLake](/images/test-of.jpeg)

And Developer will visualize it with CodeBuild report group to JUnittest`s result in xml.
Developers can easily see what percentage of their tests succeeded or which tests failed.


-[Now let`s take a look at CodeGuru.](/en/introduction/codeguru) 
 