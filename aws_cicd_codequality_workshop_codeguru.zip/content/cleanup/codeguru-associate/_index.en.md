---
title: "CodeGuru Reviewr"
weight: 63
pre: "<b>6-3. </b>"
---
 
### Delete CodeGuru Reviewr Associate Repo.

1. Go to the CodeGuru console: https://console.aws.amazon.com/CodeGuru

1. Select **Associated repositories** from Reviewer on the left menu.
    ![codeguru01](/images/codeguru-reviewer-select.png)

1. In **Associated repositories**, check the radio box of `concurrencysample` and select **Disasociate repository** in the **Action** drop box in the upper right.
    ![codeguru01](/images/clear-codegurureviewr-select.png)

1. If **status** is changed to Disassociating and then refreshed again, it will not be deleted.

[Next, delete the CodeGuru Profiler's Profiling Group.](/en/cleanup/codeguru-profiler)