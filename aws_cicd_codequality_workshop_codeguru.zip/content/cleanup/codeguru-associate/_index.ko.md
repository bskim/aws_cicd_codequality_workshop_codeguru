---
title: "CodeGuru Reviewr"
weight: 63
pre: "<b>6-3. </b>"
---
 

### CodeGuru Reviewr Associate Repo를 삭제합니다.

1.	CodeGuru 콘솔로 가기: https://console.aws.amazon.com/CodeGuru

1. 왼쪽 메뉴의 Reviewer의 **Associated repositories**를 선택합니다. 
    ![codeguru01](/images/codeguru-reviewer-select.png)

1. **Associated repositories**에서 `concurrencysample`의 라디오 박스를 체크한 후 오른쪽 상단의 **Action** 드랍박스의 **Disasociate repository**를 선택합니다.  
    ![codeguru01](/images/clear-codegurureviewr-select.png)

1. **status**가 Disassociating으로 변경된 후 다시 리프레쉬해보면 삭제되어 보이지 않습니다. 

[이제 CodeGuru Profiler의 Profiling Group를 삭제하겠습니다.](/ko/cleanup/codeguru-profiler)
