---
title: "IAM Role"
weight: 62
pre: "<b>6-2. </b>"
---
 
### IAM role을 삭제합니다.

1.	IAM 콘솔로 가기: https://console.aws.amazon.com/iam


1. 왼쪽 **Dashboard**의 **Access management**의 **Roles**를 선택한 뒤 검색창에 `CodeQuality-Workshop-WebAppRole`을 검색합니다. 검색하여 나온 결과물의 체크박스를 클릭한 후 **Delete role**을 선택합니다.  
    ![clear02](/images/clear-iam-delete.png)

1. Delete role의 **Yes, Delete**를 선택합니다.  
    ![clear03](/images/clear-iam-delete-fin.png)

- [이제 CodeGuru Reviewr의 Associate Repository를 삭제하겠습니다.](/ko/cleanup/codeguru-associate)