---
title: "CodeGuru Profiler"
weight: 64
pre: "<b>6-4. </b>"
---
 
### Delete CodeGuru Reviewr Associate Repo.

1. Go to the CodeGuru console: https://console.aws.amazon.com/CodeGuru

1. Select **Profiling groups** from the Profiler on the left menu.
    ![codeguru01](/images/codeguru-profiler-select.png)


1. In **Profiling groups**, check the radio box of `concurrencysample-sampler` and select **Delete profiling group** in the** Action** drop box in the upper right.
    ![codeguru01](/images/clear-codeguru-profiler-select.png)

1. Select **Delete** at the bottom of **Delete profiling group**.
    ![codeguru01](/images/clear-codeguruprofiler-select-fin.png)

[Next, delete the Stack of CloudFormation.](/en/cleanup/cloudformation)