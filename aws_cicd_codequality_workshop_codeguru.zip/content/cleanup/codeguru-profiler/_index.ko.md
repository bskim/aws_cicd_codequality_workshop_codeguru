---
title: "CodeGuru Profiler"
weight: 64
pre: "<b>6-4. </b>"
---
 

### CodeGuru Reviewr Associate Repo를 삭제합니다.

1.	CodeGuru 콘솔로 가기: https://console.aws.amazon.com/CodeGuru

1. 왼쪽 메뉴의 Profiler의 **Profiling groups**를 선택합니다. 
    ![codeguru01](/images/codeguru-profiler-select.png)


1. **Profiling groups**에서 `concurrencysample-sampler`의 라디오 박스를 체크한 후 오른쪽 상단의 **Action** 드랍박스의 **Delete profiling group**를 선택합니다.  
    ![codeguru01](/images/clear-codeguru-profiler-select.png)

1. **Delete profiling group**의 하단 **Delete**를 선택합니다. 
    ![codeguru01](/images/clear-codeguruprofiler-select-fin.png)

- [이제 CloudFormation의 Stack을 삭제하겠습니다.](/ko/cleanup/cloudformation)
