---
title: "Cloud9"
weight: 67
pre: "<b>6-7. </b>"

---

### Delete Cloud9.

1. Go to the Cloud9 console: https://console.aws.amazon.com/cloud9
    
1. Select the radio button for **CodequalityWorkshop`s Cloud9** in **Your environments** and **Delete** at the top.   
    ![cloud901](/images/clear-cloud9-select.png)

1. Enter `Delete` in **Delete Codequalityworkshop's Cloud9** and click the ** Delete ** button.
    ![cloud901](/images/clear-cloud9-select-fin.png)

- All data has been deleted! thanks you!!
- Best Regards
