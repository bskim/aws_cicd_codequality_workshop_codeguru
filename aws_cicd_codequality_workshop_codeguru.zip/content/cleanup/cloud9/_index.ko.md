---
title: "Cloud9"
weight: 67
pre: "<b>6-7. </b>"

---

### Cloud9을 삭제합니다.

1.	Cloud9 콘솔로 가기: https://console.aws.amazon.com/cloud9
    
1. **Your environments**의 **CodequalityWorkshop`s Cloud9**의 라디오버튼을 선택하고 상단의 **Delete**를 선택합니다.
    ![cloud901](/images/clear-cloud9-select.png)

1. **Delete Codequalityworkshop's Cloud9**에 `Delete`를 입력하고 **Delete** 버튼을 누릅니다. 
    ![cloud901](/images/clear-cloud9-select-fin.png)

-	모든 데이터를 삭제하였습니다! 고생하셨습니다!