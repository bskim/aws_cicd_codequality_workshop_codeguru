---
title: "S3 Bucket"
weight: 61
pre: "<b>6-1. </b>"
---

1.	S3 콘솔로 가기: https://console.aws.amazon.com/s3


1. Buckets의 search바에 `awsworkshop-concurrencysample-us-west-2`를 입력합니다. 그리고 검색되어 나온 버킷의 오른쪽 라디오버튼을 선택합니다. 그리고 상단의 **Empty**버튼을 누릅니다. 
    ![clear01](/images/clear-s3-empty.png)

1. Empty bucket의 Empty버튼을 활성화 하기위해 버킷네임을 입력한 후 Empty버튼을 눌러 버킷네용을 전부 삭제합니다.  
    ![clear01](/images/clear-s3-empty-fin.png)

1. 삭제가 완료됬다는 메세지가 나오면 오른쪽 위 **Exit**를 눌러서 완료합니다.
    ![clear01](/images/clear-s3-empty-fin-exit.png)


[이제 IAM role을 삭제하겠습니다.](/ko/cleanup/iam)

