---
title: "CodeBuild Report Group"
weight: 66
pre: "<b>6-6. </b>"
---
 


### Delete CodeBuild Report Group.

1. Go to the CodeBuild console: https://console.aws.amazon.com/CodeBuild

1. In **Report groups**, check the radio box of `Concurrency-uniitest-Report` and push **Delete**.
    ![codeguru01](/images/clear-codebuild-select.png)

1. Enter `delete` in the ** Delete ** window and press the ** Delete ** button!
    ![codeguru011](/images/clear-codebuild-select-fin.png)
    (If it is not deleted, you can delete all the build results inside the scroll.)

[Next delete Cloud9](/en/cleanup/cloud9)


