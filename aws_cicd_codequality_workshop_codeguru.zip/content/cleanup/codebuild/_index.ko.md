---
title: "CodeBuild Report Group"
weight: 66
pre: "<b>6-6. </b>"
---
 


### CodeBuild Report Group을 삭제합니다.

1.	CodeBuild 콘솔로 가기: https://console.aws.amazon.com/CodeBuild

1. **Report groups**에서 `Concurrency-uniitest-Report`의 라디오 박스를 체크한 후 오른쪽 상단의 **Delete**를 선택합니다.
    ![codeguru01](/images/clear-codebuild-select.png)

1. **Delete**창에 `delete`를 입력한 후 **Delete**버튼을 누릅니다!
    ![codeguru011](/images/clear-codebuild-select-fin.png)
    (삭제가 되지 않는다면 스크롤 아래 내부의 빌드 결과를 모두 삭제하시면 됩니다.)

[이제 Cloud9을 삭제하겠습니다.](/ko/cleanup/cloud9)


