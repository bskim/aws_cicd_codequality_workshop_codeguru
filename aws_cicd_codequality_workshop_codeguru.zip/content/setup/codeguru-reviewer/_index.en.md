---
title: "CodeGuru Reviewer"
weight: 23
pre: "<b>2-3. </b>"

---

### **CodeGuru Reviewer** setup.

go to the CodeGuru console : https://console.aws.amazon.com/codeguru

1. Select **Associated repositories** from Reviewer on the left menu.
    ![codeguru01](/images/codeguru-reviewer-select.png)

1. Select **Associate repository** at the top right.
    ![codeguru01](/images/codeguru-associate-repository.png)

1. Select **AWS CodeCommit** as the Source provider for Repository details, then select **concurrencysample** at Repository location. and click Associate.
    ![codeguru01](/images/codeguru-associate.png)

1. Check the connected concurrencysample in Codeguru's Dashboard.
    ![codeguru01](/images/codeguru-fin.png)

1. CodeGuru and CodeCommit are linked.

-[ Now let`s connect CodeGuru Profiler to CodeCommit. ](/en/setup/codeguru-profiler) 
